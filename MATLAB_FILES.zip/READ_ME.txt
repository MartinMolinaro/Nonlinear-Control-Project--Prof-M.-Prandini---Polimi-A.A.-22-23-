Instructions to run the Matlab/Simulink files:
-Run first the main code "main_robot_arm.m"
-For the simulink schemes the std reference is a step, but you can also put for testing the commented sinusoidal reference
-To visualize the equilibria you can run the "equilibria.m" code (always run first the main with the data), note that the higher the "resolution" 
 the higher will be the execution time