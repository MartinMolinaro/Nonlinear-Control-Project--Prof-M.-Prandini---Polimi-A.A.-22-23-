clear all;
close all;
clc;

%% State space representation
syms thl thld thldd thm thmd thmdd Jl Bl k m l g Jm Bm u
eq1 = Jl*thldd + Bl*thld + k*(thl-thm)+m*g*l*cos(thl) == 0;
eq2 = Jm*thmdd + Bm*thmd - k*(thl-thm) == u;

eq3 = isolate(eq1,thldd); % thldd
eq4 = isolate(eq2,thmdd); % thmdd

% x1 = thl, x2 = thm, x3 = thld, x4 = thmd
syms x1 x2 x3 x4 x1d x2d x3d x4d
x1d = x3;
x2d = x4;
x3d = rhs(subs(eq3,[thl thm thld thmd],[x1 x2 x3 x4]));
x4d = collect(rhs(subs(eq4,[thl thm thld thmd],[x1 x2 x3 x4])), u);


%% Data
k = 0.8;
Jm = 4e-4; %robustness test: put 5e-4 %std 4e-4
Jl = 4e-4; %robustness test: put 5e-4 %std 4e-4
Bm = 0.015;
Bl = 0;
m = 0.3;
l = 0.3;
g = 9.8;

%% Equilibrium for linearizing with tangent model
thl0=pi/4; %most isolated equilibrium to test: -2.0944 [rad] %given pi/4
x2_0= m*g*l/k*cos(thl0)+thl0;
u0=k*(x2_0-thl0);
x0=[thl0; x2_0; 0; 0];

%% Tangent linearization (tl)
A_tl=[0 0 1 0;
      0 0 0 1;
      1/Jl*(-k+m*g*l*sin(thl0)) k/Jl -Bl/Jl 0;
      k/Jm -k/Jm 0 -Bm/Jm];
B_tl=[0; 0 ; 0 ; 1/Jm];
C_tl=[1 0 0 0];
D_tl=0;

sys_tl = ss(A_tl, B_tl, C_tl, D_tl);
[num,den] = ss2tf(A_tl,B_tl,C_tl,D_tl);
G_tl=tf(num,den); 

zeroes = zero(G_tl);
poles = pole(G_tl);
rank(ctrb(sys_tl)); % = 4, controllable
rank(obsv(sys_tl)); % = 4, observable



%% (tl) STABILIZING METHOD: POLE PLACEMENT (pp) 
% Pole placement (pp) (same poleS used later on for system linearized with state feedback, for comparison)
P_tl = [-15;-30;-45;-60];
Kpp_tl = place(A_tl,B_tl,P_tl);

% T.F. for PI controller design
G_pp_tl = tf(ss(A_tl-B_tl*Kpp_tl,B_tl,C_tl,D_tl));

%% (tl) PI controller design (same controller of state feedback lin. sys-->FOR DIRECT COMPARISON)
opts_pp_tl = pidtuneOptions('PhaseMargin',75);
R_tl = pid(pidtune(G_pp_tl, 'PI', 4, opts_pp_tl));
R_tl =tf(R_tl);

%% (tl) Feedback functions
stabilizing_feedback = feedback(R_tl*G_pp_tl,1);
sensitivity = R_tl/(1 + R_tl*G_pp_tl);


% %% (tl) Theoretical results on tangent-linearized system
% figure
% 
% step(stabilizing_feedback);
% title("Theoretical step response of tangent-linearized system"); grid on;
% xlabel("time (s)");
% ylabel("output y_lin");
% 
% figure
% 
% step(sensitivity);
% title("Theoretical control signal for tangent-linearized system"); grid on;
% xlabel("time (s)");
% ylabel("input u_lin");

%% State feedback linearization (fl)
%% (fl) I/O linearizability analysis
% Check if the order of the system n=4 is equal to the relative degree r .
% If n=r=4 => FULLY LINEARIZABLE
%% (fl) Degree of the system
syms a(x) b(x) c(x)
x = [x1; x2; x3; x4];
a = [   x3;
        x4;
        -(Bl*x3 + k*(x1 - x2) + g*l*m*cos(x1))/Jl;
        - (Bm*x4 - k*(x1 - x2))/Jm];
b = [0;0;0;1/Jm];
c = pi/4 - x1;

%% (fl) Computation of Lie Derivatives
Lac0=c;
Lac1=jacobian(c,x)*a;
Lac2=jacobian(Lac1,x)*a;
Lac3=jacobian(Lac2,x)*a;
Lac4=jacobian(Lac3,x)*a;
Lb1=jacobian(c,x)*b;
Lb2=jacobian(Lac1,x)*b;
Lb3=jacobian(Lac2,x)*b;
Lb4=jacobian(Lac3,x)*b; % different from 0!->r=4 => FULLY LINEARIZABLE

%% (fl) Change of coordinates
% control law definition 
syms v
u = (v - Lac4)/Lb4;

% change of coordinates - useful for Simulink
phi1 = Lac0;
phi2 = Lac1;
phi3 = Lac2;
phi4 = Lac3;
phi = [phi1; phi2; phi3; phi4];
det(jacobian(phi,x)); % invertible

% inverse change of coordinates - useful for Simulink
syms xtilde1 xtilde2 xtilde3 xtilde4 xtilde1d xtilde2d xtilde3d xtilde4d xtilded utilde vtilde
[iphi1, iphi2, iphi3, iphi4] = solve(xtilde1==phi(1),xtilde2==phi(2),xtilde3==phi(3),xtilde4==phi(4),x1,x2,x3,x4);
iphi = [iphi1; iphi2; iphi3; iphi4];



%% (fl) Tilde system and pole placement
% The tilde system is the one with 4 integrators
xtildebar = [3*pi/4 0 0 0]'; % equilibrium of the tilde system

% We need to change to a deltaxtilde coordinate to have 0 equilibrium with 0 input.
% The project of the pole placement is the same as doing it on the xtilde system,
% but instead of using v = gamma- K*deltaxtilde, one must use v = (gamma + K*xtildebar) - K*xtilde. 

A = [0 1 0 0;
     0 0 1 0;
     0 0 0 1;
     0 0 0 0];
B=[0 0 0 1]';
C=[1 0 0 0];



% controllable?
rk=rank(ctrb(A,B))
P = [-15;-30;-45;-60]; 
K = place(A,B,P);


%% (fl) T.F. for PI controller
G = tf(ss(A-B*K,B,C,0));


%% (fl) PI CONTROLLER (same design used for tl sys.)
opts = pidtuneOptions('PhaseMargin',75);
R = pid(pidtune(G, 'PI', 4, opts));
R =tf(R);


%% (fl) Feedback functions
stabilizing_feedback_fl = feedback(R*G,1);
sensitivity_fl = R/(1 + R*G);


% %% (fl) Theoretical results on feedback-linearized system
% figure
% 
% step(stabilizing_feedback_fl);
% title("Theoretical step response of feedback-linearized system"); grid on;
% xlabel("time (s)");
% ylabel("output y");
% 
% figure
% 
% step(sensitivity_fl);
% title("Theoretical control signal for feedback-linearized system"); grid on;
% xlabel("time (s)");
% ylabel("input u");

