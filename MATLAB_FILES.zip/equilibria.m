
%% Graphical analysis for the equilibria x10,x20 (x30=x40=0 always)

% To run after the main_robot_arm.m script (please don't clear the workspace before running this script)
% Separated from the rest of the code because it would have slow it down

figure; grid on;
title('Equilibria for \theta_{l}=-2\pi-2\pi, (x3_0=x4_0=0)')
xlabel('x1_0=\theta_{l}')
ylabel('x2_0=\theta_{m}')

resolution=60; % the higher the better resolution, but it will take more time

for thlbar=-2*pi:pi/resolution:2*pi
x2bar= m*g*l/k*cos(thlbar)+thlbar;
ubar=k*(x2bar-thlbar);
[x10, x20, x30, x40] = solve(x3==0, x4==0, -1/Jl*(Bl*x3+k*(x1-x2)+m*g*l*cos(x1))==0, 1/Jm*(-Bm*x4+k*(x1-x2)+ubar)==0, x1,x2,x3,x4)

hold on
scatter(x10,x20)
set(gca,'XTick',-2*pi:pi/4:2*pi)
set(gca,'XTickLabel',{'-2\pi','-7\pi/4','-3\pi/2','-5\pi/4','-\pi','-3\pi/4','-\pi/2','-\pi/4','0','\pi/4','\pi/2','3\pi/4','\pi','5\pi/4','3\pi/2','7\pi/4','2\pi'})
set(gca,'YTick',-2*pi:pi/4:2*pi)
set(gca,'YTickLabel',{'-2\pi','-7\pi/4','-3\pi/2','-5\pi/4','-\pi','-3\pi/4','-\pi/2','-\pi/4','0','\pi/4','\pi/2','3\pi/4','\pi','5\pi/4','3\pi/2','7\pi/4','2\pi'})
end

